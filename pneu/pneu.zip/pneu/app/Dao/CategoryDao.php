<?php 

namespace App\Dao;

class CategoryDao
{
    
}