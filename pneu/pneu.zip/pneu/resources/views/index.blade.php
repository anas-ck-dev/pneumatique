<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Pneumatiques belhassan</title>

    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.2/css/all.min.css">
    <meta name="keywords" content="Pneumatiques belhassan,Pneumatiques " />
    <meta name="description" content="Pneumatiques belhassan">

    <script src="https://code.jquery.com/jquery-3.6.0.min.js"></script>
    @include('layouts/header')

    <main class="main">
        <div class="intro-slider slide-animate owl-carousel owl-theme show-nav-hover nav-inside nav-big"
            data-owl-options="{
                'loop': false,
                'dots': false,
                'nav': true
			}">
            <div class="banner intro-slide1"
                style="background: url(/assets/images/demoes/style2/slider/slide1.jpg) rgb(255, 255, 255);
                min-height: 530px; background-position: right center; background-repeat: no-repeat;">
                <div class="container">
                    <div class="wrapper">
                        <svg class="custom-svg-1" version="1.1" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                            viewBox="0 0 649 578">
                            <path fill="#FFF"
                                d="M-225.5,154.7l358.45,456.96c7.71,9.83,21.92,11.54,31.75,3.84l456.96-358.45c9.83-7.71,11.54-21.92,3.84-31.75
                                    L267.05-231.66c-7.71-9.83-21.92-11.54-31.75-3.84l-456.96,358.45C-231.49,130.66-233.2,144.87-225.5,154.7z">
                            </path>
                            <path class="appear-animate appear-animate-svg" data-animation-name="customLineAnim"
                                data-animation-duration="5000" fill="none" stroke="#222529" stroke-width="1.5"
                                stroke-miterlimit="10" d="M416-21l202.27,292.91c5.42,7.85,3.63,18.59-4.05,24.25L198,603"
                                style="animation-delay: 300ms; animation-duration: 5s;"></path>
                        </svg>
                    </div>
                    <div class="row h-100">
                        <div class="col-md-5 banner-media appear-animate d-none d-md-block"
                            data-animation-name="fadeInRightShorter">
                            <img src="/assets/images/demoes/style2/banner1.jpg" width="426" height="426"
                                alt="banner" />

                        </div>
                        <div class="col-md-7">
                            <div class="banner-content banner-layer-middle">
                                <div class=" appear-animate" data-animation-name="fadeInLeftShorter"
                                    data-animation-delay="500">
                                    <h2 class="banner-title pb-1">Notre plateforme de vente en ligne vous propose une
                                        multitude de marques, ce qui nous permet d'avoir des prix adaptés à tous les
                                        budgets.</h2>
                                    <div class="banner-action">
                                        <a href="#produits" class="btn btn-primary btn-rounded btn-icon-right"
                                            role="button">Achetez
                                            <i class="fas fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            {{-- <div class="banner intro-slide2"
                style="background: url(/assets/images/demoes/style2/slider/slide2.jpg) rgb(255, 255, 255);
                min-height: 530px; background-position: left center; background-repeat: no-repeat;">
                <div class="container">
                    <div class="wrapper">
                        <svg class="custom-svg-2" version="1.1" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                            viewBox="0 0 649 578">
                            <path fill="#FFF"
                                d="M-225.5,154.7l358.45,456.96c7.71,9.83,21.92,11.54,31.75,3.84l456.96-358.45c9.83-7.71,11.54-21.92,3.84-31.75
                                    L267.05-231.66c-7.71-9.83-21.92-11.54-31.75-3.84l-456.96,358.45C-231.49,130.66-233.2,144.87-225.5,154.7z">
                            </path>
                            <path class="appear-animate appear-animate-svg" data-animation-name="customLineAnim"
                                data-animation-duration="5000" fill="none" stroke="#222529" stroke-width="1.5"
                                stroke-miterlimit="10" d="M416-21l202.27,292.91c5.42,7.85,3.63,18.59-4.05,24.25L198,603"
                                style="animation-delay: 300ms; animation-duration: 5s;"></path>
                        </svg>
                    </div>
                    <div class="row h-100">
                        <div class="col-md-7">
                            <div class="banner-content banner-layer-middle text-right">
                                <div class=" appear-animate" data-animation-name="fadeInRightShorter"
                                    data-animation-delay="500">
                                    <div class="brand-logo px-3 mb-1">
                                        <img src="/assets/images/demoes/style2/new_brand3_light.png" width="140"
                                            height="60" alt="brand" />
                                    </div>
                                    <h3 class="banner-subtitle pt-1 mb-1">Économisez jusqu'à 30 % </h3>
                                    <h2 class="banner-title pb-1">Kit de freinage haute performance
                                    </h2>



                                    <ul class="info-list mr-0">
                                        <li><i class="far fa-check-circle"></i>
                                            <div class="porto-info-list-item-desc">Meilleure dissipation de la chaleur

                                            </div>
                                        </li>
                                        <li><i class="far fa-check-circle"></i>
                                            <div class="porto-info-list-item-desc">Kit boulonné complet

                                            </div>
                                        </li>
                                        <li><i class="far fa-check-circle"></i>
                                            <div class="porto-info-list-item-desc">
                                                Fabriqué aux Etats-Unis
                                            </div>
                                        </li>
                                    </ul>

                                    <div class="banner-action">
                                        <a href="#produits" class="btn btn-primary btn-rounded btn-icon-right"
                                            role="button">Boutique
                                            Maintenant
                                            <i class="fas fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                        <div class="col-md-5 banner-media appear-animate d-none d-md-block"
                            data-animation-name="fadeInLeftShorter">
                            <img src="/assets/images/demoes/style2/banner2.jpg" width="504" height="347"
                                alt="banner" />
                            <div class="mark-deal"><i>%
                                </i></div>
                        </div>

                    </div>
                </div>
            </div> --}}
        </div>



        <section class="search-section" style="background-color: #f4f4f4;">
            <div class="container">
                <div class="row justify-content-center">

                    <div class="col-sm-12 col-md-4">
                        <h2 class="search-title p-2 mr-4"><i class="icon-business-book"></i>TROUVEZ VOTRE PRODUIT:</h2>
                    </div>

                    <div class="col-sm-12 col-md-3">
                        <input class="form-control mb-0" type="txt" id="search-input" placeholder="Recherche..." >
                    </div>


                    <div class="col-sm-12 col-md-4">
                        <div class="select-custom">
                            <select class="form-control mb-0" name="search_categorie" id="select1">
                                <option @isset($category)  @endisset>
                                    @isset($category)
                                        {{ $category->name }}
                                    @else
                                        Par Categories
                                    @endisset
                                </option>
                                @empty($category->id)
                                    <?php $category_id = 0; ?>
                                    @else
                                    <?php $category_id = $category->id; ?>
                                @endempty

                                @foreach ($categorys as $category1)
                                    <option value="{{ $category1->id }}"
                                        @if ($category_id == $category1->id) selected @endif>
                                        {{ $category1->name }}</option>
                                @endforeach
                            </select>
                        </div>
                    </div>
                    <div class="col-sm-12 col-md-1">
                        <a href="/" >
<svg xmlns="http://www.w3.org/2000/svg" xmlns:xlink="http://www.w3.org/1999/xlink" width="50" zoomAndPan="magnify" viewBox="0 0 375 374.999991" height="50" preserveAspectRatio="xMidYMid meet" version="1.0"><defs><clipPath id="336882796b"><path d="M 15.394531 15.394531 L 359.644531 15.394531 L 359.644531 359.644531 L 15.394531 359.644531 Z M 15.394531 15.394531 " clip-rule="nonzero"/></clipPath><clipPath id="8ca48c648a"><path d="M 86.269531 86.269531 L 354.382812 86.269531 L 354.382812 354.382812 L 86.269531 354.382812 Z M 86.269531 86.269531 " clip-rule="nonzero"/></clipPath><clipPath id="fd994d09c5"><path d="M 359.644531 187.519531 C 359.644531 282.582031 282.582031 359.644531 187.519531 359.644531 C 92.457031 359.644531 15.394531 282.582031 15.394531 187.519531 C 15.394531 92.457031 92.457031 15.394531 187.519531 15.394531 C 282.582031 15.394531 359.644531 92.457031 359.644531 187.519531 " clip-rule="nonzero"/></clipPath></defs><g clip-path="url(#336882796b)"><path fill="#196dc5" d="M 359.644531 187.519531 C 359.644531 282.582031 282.585938 359.644531 187.519531 359.644531 C 92.457031 359.644531 15.394531 282.582031 15.394531 187.519531 C 15.394531 92.457031 92.457031 15.394531 187.519531 15.394531 C 282.585938 15.394531 359.644531 92.457031 359.644531 187.519531 " fill-opacity="1" fill-rule="nonzero"/></g><g clip-path="url(#8ca48c648a)"><g clip-path="url(#fd994d09c5)"><path fill="#175494" d="M 231.226562 354.046875 L 123.265625 265.8125 C 123.207031 265.765625 123.148438 265.714844 123.089844 265.664062 C 122.523438 265.199219 121.957031 264.726562 121.398438 264.25 C 121.324219 264.183594 121.25 264.121094 121.175781 264.054688 C 120.640625 263.589844 120.105469 263.117188 119.578125 262.640625 C 119.511719 262.582031 119.445312 262.527344 119.378906 262.46875 C 118.832031 261.972656 118.289062 261.46875 117.753906 260.957031 C 117.644531 260.855469 117.539062 260.753906 117.429688 260.652344 C 116.902344 260.144531 116.375 259.636719 115.855469 259.113281 L 115.765625 259.03125 C 115.6875 258.953125 115.613281 258.871094 115.535156 258.792969 C 115.210938 258.46875 114.890625 258.136719 114.570312 257.808594 C 114.441406 257.675781 114.3125 257.542969 114.183594 257.40625 C 113.824219 257.03125 113.464844 256.648438 113.105469 256.265625 C 113.046875 256.203125 112.992188 256.140625 112.933594 256.078125 C 112.523438 255.632812 112.117188 255.179688 111.714844 254.730469 C 111.601562 254.605469 111.492188 254.480469 111.382812 254.355469 C 111.082031 254.011719 110.78125 253.664062 110.484375 253.316406 C 110.363281 253.175781 110.246094 253.039062 110.125 252.898438 C 109.765625 252.472656 109.410156 252.042969 109.054688 251.609375 C 109.019531 251.570312 108.988281 251.53125 108.953125 251.492188 C 108.570312 251.019531 108.191406 250.542969 107.8125 250.0625 C 107.707031 249.925781 107.597656 249.789062 107.492188 249.652344 C 107.210938 249.289062 106.929688 248.921875 106.652344 248.558594 C 106.546875 248.414062 106.4375 248.273438 106.332031 248.128906 C 105.964844 247.636719 105.601562 247.144531 105.242188 246.648438 C 78.363281 209.234375 80.433594 157.878906 109.675781 122.734375 L 102.988281 113.421875 C 101.632812 111.542969 101.550781 109.03125 102.769531 107.058594 C 102.847656 106.9375 102.929688 106.816406 103.015625 106.699219 L 103.09375 106.59375 C 103.15625 106.511719 103.222656 106.433594 103.289062 106.355469 L 103.382812 106.246094 C 103.457031 106.164062 103.53125 106.085938 103.609375 106.011719 L 103.679688 105.9375 C 103.78125 105.839844 103.886719 105.746094 103.996094 105.65625 L 104.011719 105.644531 L 104.066406 105.601562 C 104.160156 105.527344 104.257812 105.457031 104.351562 105.386719 C 104.390625 105.363281 104.425781 105.339844 104.460938 105.3125 C 104.558594 105.246094 104.660156 105.1875 104.761719 105.128906 L 104.839844 105.082031 C 104.964844 105.011719 105.097656 104.945312 105.226562 104.882812 L 105.328125 104.839844 C 105.429688 104.792969 105.535156 104.753906 105.640625 104.714844 C 105.679688 104.695312 105.722656 104.679688 105.765625 104.667969 C 105.886719 104.625 106.007812 104.589844 106.128906 104.554688 L 106.1875 104.539062 C 106.328125 104.5 106.46875 104.46875 106.613281 104.441406 C 106.652344 104.4375 106.695312 104.429688 106.734375 104.421875 C 106.84375 104.40625 106.953125 104.390625 107.066406 104.378906 C 107.109375 104.375 107.152344 104.371094 107.195312 104.367188 C 107.34375 104.355469 107.492188 104.347656 107.640625 104.347656 C 107.945312 104.347656 108.257812 104.371094 108.566406 104.421875 L 145.804688 110.515625 L 141.601562 104.671875 C 140.613281 103.296875 140.285156 101.550781 140.707031 99.910156 C 140.753906 99.726562 140.8125 99.546875 140.875 99.367188 C 140.894531 99.316406 140.914062 99.269531 140.933594 99.21875 C 140.988281 99.085938 141.046875 98.953125 141.109375 98.820312 C 141.128906 98.777344 141.152344 98.734375 141.171875 98.695312 C 141.257812 98.527344 141.347656 98.367188 141.449219 98.210938 L 141.507812 98.132812 C 141.59375 98.003906 141.683594 97.878906 141.78125 97.757812 C 141.8125 97.714844 141.847656 97.675781 141.882812 97.632812 C 141.984375 97.515625 142.082031 97.402344 142.191406 97.296875 L 142.265625 97.21875 C 142.382812 97.105469 142.503906 96.996094 142.628906 96.890625 L 142.671875 96.863281 C 142.785156 96.769531 142.90625 96.6875 143.023438 96.605469 C 143.085938 96.566406 143.140625 96.519531 143.203125 96.480469 C 143.390625 96.363281 143.582031 96.257812 143.78125 96.160156 C 157.472656 89.597656 172.148438 86.269531 187.410156 86.269531 C 188.171875 86.269531 188.933594 86.28125 189.695312 86.300781 C 189.835938 86.304688 189.976562 86.304688 190.117188 86.308594 C 190.851562 86.328125 191.582031 86.355469 192.3125 86.390625 C 192.453125 86.398438 192.589844 86.40625 192.734375 86.414062 C 193.480469 86.453125 194.230469 86.5 194.972656 86.554688 L 195.003906 86.554688 C 195.757812 86.613281 196.507812 86.679688 197.257812 86.753906 C 197.398438 86.769531 197.539062 86.78125 197.679688 86.796875 C 198.40625 86.871094 199.128906 86.949219 199.847656 87.039062 C 199.984375 87.054688 200.117188 87.074219 200.253906 87.09375 C 200.988281 87.1875 201.71875 87.285156 202.449219 87.394531 L 202.503906 87.402344 C 203.242188 87.511719 203.980469 87.636719 204.714844 87.761719 C 204.855469 87.785156 204.996094 87.8125 205.140625 87.835938 C 205.851562 87.964844 206.5625 88.097656 207.269531 88.238281 C 207.402344 88.265625 207.535156 88.292969 207.667969 88.320312 C 208.378906 88.464844 209.089844 88.617188 209.796875 88.777344 L 209.878906 88.792969 C 210.601562 88.960938 211.324219 89.132812 212.042969 89.3125 C 212.183594 89.347656 212.324219 89.382812 212.464844 89.417969 C 213.160156 89.597656 213.855469 89.78125 214.546875 89.972656 C 214.675781 90.007812 214.804688 90.046875 214.929688 90.082031 C 215.625 90.277344 216.3125 90.476562 217 90.6875 L 217.105469 90.71875 C 217.808594 90.933594 218.511719 91.160156 219.210938 91.390625 C 219.351562 91.433594 219.488281 91.480469 219.625 91.527344 C 220.304688 91.753906 220.984375 91.988281 221.660156 92.230469 C 221.78125 92.273438 221.902344 92.320312 222.027344 92.363281 C 222.695312 92.605469 223.359375 92.855469 224.023438 93.109375 C 224.066406 93.125 224.105469 93.140625 224.148438 93.15625 C 224.832031 93.421875 225.515625 93.699219 226.191406 93.980469 C 226.324219 94.035156 226.460938 94.089844 226.59375 94.144531 C 227.253906 94.421875 227.914062 94.707031 228.570312 94.996094 C 228.6875 95.046875 228.800781 95.097656 228.917969 95.152344 C 229.5625 95.4375 230.203125 95.734375 230.84375 96.035156 C 230.886719 96.054688 230.933594 96.078125 230.980469 96.101562 C 231.644531 96.414062 232.300781 96.738281 232.953125 97.0625 C 233.082031 97.128906 233.214844 97.195312 233.34375 97.261719 C 233.984375 97.585938 234.621094 97.914062 235.25 98.253906 C 235.363281 98.3125 235.472656 98.371094 235.582031 98.429688 C 236.199219 98.761719 236.816406 99.101562 237.425781 99.445312 C 237.476562 99.472656 237.527344 99.5 237.574219 99.527344 C 238.210938 99.890625 238.84375 100.257812 239.46875 100.632812 C 239.59375 100.707031 239.722656 100.785156 239.847656 100.859375 C 240.460938 101.230469 241.070312 101.605469 241.679688 101.988281 C 241.78125 102.050781 241.882812 102.117188 241.988281 102.183594 C 242.578125 102.558594 243.164062 102.941406 243.746094 103.328125 C 243.796875 103.363281 243.851562 103.398438 243.90625 103.429688 C 244.511719 103.839844 245.113281 104.253906 245.714844 104.671875 C 245.832031 104.753906 245.953125 104.839844 246.070312 104.921875 C 246.660156 105.339844 247.242188 105.757812 247.820312 106.1875 C 247.917969 106.257812 248.011719 106.328125 248.109375 106.402344 C 248.667969 106.816406 249.222656 107.238281 249.773438 107.664062 C 249.828125 107.710938 249.882812 107.75 249.9375 107.792969 C 250.515625 108.242188 251.085938 108.699219 251.652344 109.160156 C 251.765625 109.253906 251.878906 109.347656 251.992188 109.441406 C 252.550781 109.902344 253.101562 110.363281 253.648438 110.832031 C 253.738281 110.910156 253.824219 110.988281 253.914062 111.066406 C 254.441406 111.519531 254.964844 111.980469 255.480469 112.449219 C 255.535156 112.5 255.59375 112.550781 255.648438 112.597656 C 256.191406 113.089844 256.726562 113.589844 257.257812 114.089844 C 257.363281 114.195312 257.472656 114.296875 257.582031 114.398438 C 258.105469 114.898438 258.625 115.40625 259.136719 115.917969 L 259.21875 115.996094 C 259.269531 116.050781 259.324219 116.105469 259.378906 116.160156 C 259.871094 116.65625 260.363281 117.160156 260.847656 117.667969 C 260.902344 117.722656 260.957031 117.777344 261.011719 117.835938 C 261.519531 118.371094 262.019531 118.910156 262.511719 119.457031 C 262.613281 119.566406 262.714844 119.675781 262.816406 119.789062 C 263.304688 120.332031 263.785156 120.875 264.261719 121.429688 C 264.339844 121.519531 264.414062 121.609375 264.492188 121.695312 C 264.949219 122.234375 265.402344 122.773438 265.847656 123.316406 C 265.886719 123.363281 265.921875 123.40625 265.960938 123.449219 L 354.046875 231.230469 C 338.359375 291.164062 291.164062 338.359375 231.226562 354.046875 M 107.640625 104.550781 C 105.714844 104.550781 103.957031 105.53125 102.941406 107.167969 C 101.757812 109.074219 101.839844 111.484375 103.152344 113.304688 L 109.839844 122.617188 C 109.894531 122.691406 109.890625 122.792969 109.832031 122.863281 C 95.6875 139.859375 87.445312 161.515625 86.613281 183.847656 C 85.785156 206.246094 92.457031 228.507812 105.40625 246.527344 C 124.332031 272.851562 155.054688 288.570312 187.59375 288.570312 C 202.816406 288.570312 217.464844 285.25 231.140625 278.695312 C 232.621094 277.992188 233.703125 276.671875 234.109375 275.082031 C 234.515625 273.492188 234.203125 271.816406 233.242188 270.484375 L 229.035156 264.632812 C 228.988281 264.566406 228.988281 264.476562 229.027344 264.40625 C 229.066406 264.347656 229.132812 264.308594 229.199219 264.308594 L 229.234375 264.3125 L 265.539062 270.25 C 265.84375 270.300781 266.144531 270.324219 266.433594 270.324219 C 268.363281 270.324219 270.117188 269.34375 271.132812 267.707031 C 272.3125 265.796875 272.230469 263.390625 270.921875 261.566406 L 264.722656 252.949219 C 264.667969 252.871094 264.671875 252.769531 264.734375 252.699219 C 279.097656 235.683594 287.507812 213.964844 288.414062 191.542969 C 289.324219 169.050781 282.640625 146.667969 269.59375 128.519531 C 250.683594 102.191406 219.960938 86.472656 187.410156 86.472656 C 172.179688 86.472656 157.527344 89.792969 143.867188 96.34375 C 142.390625 97.054688 141.308594 98.371094 140.902344 99.960938 C 140.496094 101.550781 140.8125 103.222656 141.765625 104.554688 L 145.96875 110.398438 C 146.015625 110.464844 146.019531 110.554688 145.972656 110.625 C 145.9375 110.683594 145.871094 110.71875 145.804688 110.71875 L 145.769531 110.71875 L 108.535156 104.621094 C 108.238281 104.574219 107.9375 104.550781 107.640625 104.550781 " fill-opacity="1" fill-rule="nonzero"/></g></g><path fill="#ffffff" d="M 226.054688 258.1875 L 232.664062 217.808594 L 242.554688 231.570312 C 261.808594 207.476562 263.667969 172.585938 244.808594 146.335938 C 231.039062 127.183594 209.386719 116.992188 187.425781 116.992188 C 178.554688 116.992188 169.628906 118.652344 161.160156 122.0625 L 146.257812 101.328125 C 159.359375 95.050781 173.425781 92.003906 187.410156 92.003906 C 217.148438 92.003906 246.46875 105.804688 265.105469 131.746094 C 292.066406 169.253906 287.828125 219.820312 257.5625 252.460938 L 266.429688 264.796875 Z M 187.59375 283.042969 C 157.863281 283.042969 128.539062 269.234375 109.894531 243.300781 C 83.078125 205.976562 87.132812 155.730469 116.980469 123.078125 L 107.640625 110.078125 L 148.019531 116.6875 L 141.410156 157.070312 L 132.03125 144.019531 C 113.175781 168.09375 111.480469 202.652344 130.203125 228.707031 C 143.96875 247.863281 165.625 258.054688 187.585938 258.054688 C 196.457031 258.054688 205.378906 256.390625 213.851562 252.984375 L 228.753906 273.710938 C 215.652344 279.988281 201.582031 283.042969 187.59375 283.042969 Z M 264.886719 252.828125 C 294.589844 217.648438 296.839844 166.074219 269.757812 128.402344 C 250.808594 102.019531 220.023438 86.269531 187.410156 86.269531 C 172.148438 86.269531 157.472656 89.597656 143.78125 96.160156 C 142.253906 96.894531 141.125 98.265625 140.707031 99.910156 C 140.285156 101.550781 140.613281 103.296875 141.601562 104.671875 L 145.804688 110.515625 L 108.566406 104.421875 C 108.257812 104.371094 107.949219 104.347656 107.640625 104.347656 C 105.679688 104.347656 103.828125 105.355469 102.769531 107.058594 C 101.550781 109.03125 101.632812 111.542969 102.988281 113.421875 L 109.675781 122.734375 C 80.433594 157.878906 78.363281 209.234375 105.242188 246.648438 C 124.203125 273.023438 154.988281 288.769531 187.59375 288.769531 C 202.84375 288.769531 217.527344 285.441406 231.226562 278.878906 C 232.757812 278.148438 233.886719 276.777344 234.308594 275.132812 C 234.730469 273.488281 234.398438 271.746094 233.40625 270.367188 L 229.199219 264.511719 L 265.507812 270.453125 C 265.816406 270.5 266.125 270.527344 266.433594 270.527344 C 268.394531 270.527344 270.25 269.519531 271.304688 267.8125 C 272.527344 265.84375 272.441406 263.332031 271.085938 261.449219 L 264.886719 252.828125 " fill-opacity="1" fill-rule="nonzero"/><path fill="#ffffff" d="M 187.582031 264.023438 C 162.941406 264.023438 139.675781 252.125 125.351562 232.191406 C 105.640625 204.765625 106.453125 166.996094 127.328125 140.34375 C 128.460938 138.894531 130.199219 138.050781 132.03125 138.050781 C 132.070312 138.050781 132.109375 138.050781 132.152344 138.050781 C 134.03125 138.089844 135.78125 139.011719 136.878906 140.535156 L 137.84375 141.882812 L 141.160156 121.617188 L 120.898438 118.300781 L 121.828125 119.59375 C 123.476562 121.886719 123.289062 125.019531 121.382812 127.105469 C 92.957031 158.207031 90.164062 205.609375 114.738281 239.820312 C 131.503906 263.144531 158.738281 277.070312 187.59375 277.070312 C 198.664062 277.070312 209.394531 275.089844 219.574219 271.171875 L 211.648438 260.148438 C 203.902344 262.71875 195.828125 264.023438 187.582031 264.023438 " fill-opacity="1" fill-rule="nonzero"/><path fill="#ffffff" d="M 260.265625 135.230469 C 243.5 111.898438 216.261719 97.972656 187.410156 97.972656 C 176.339844 97.972656 165.613281 99.953125 155.433594 103.863281 L 163.363281 114.894531 C 171.109375 112.320312 179.183594 111.015625 187.425781 111.015625 C 212.066406 111.015625 235.332031 122.917969 249.660156 142.847656 C 269.574219 170.5625 268.570312 208.578125 247.21875 235.292969 C 246.085938 236.714844 244.363281 237.535156 242.554688 237.535156 C 242.503906 237.535156 242.453125 237.535156 242.402344 237.53125 C 240.53125 237.484375 238.796875 236.566406 237.703125 235.050781 L 236.226562 232.996094 L 232.910156 253.261719 L 253.171875 256.574219 L 252.71875 255.945312 C 251.0625 253.636719 251.261719 250.480469 253.191406 248.398438 C 282.050781 217.277344 285.023438 169.683594 260.265625 135.230469 " fill-opacity="1" fill-rule="nonzero"/></svg>

                        </a>

                        </div>
                </div>

            </div>
        </section>
        <script>
            $('#select1').trigger('change');

            $("#select1")
                .on("change", function() {
                    var str = "";
                    $("select option:selected").each(function() {
                        str += $(this).val() + " ";
                        window.location = '/product/search/' + str;
                    });

                });
        </script>
        <div class="container" id="produits">
            <h2 class="title title-underline pb-1 appear-animate mt-3" data-animation-name="fadeInLeftShorter">Produits</h2>

            <nav class="toolbox sticky-header horizontal-filter mb-1" data-sticky-options="{'mobile': true}">
                <div class="toolbox-left">


                    <div class="toolbox-item filter-toggle  d-lg-flex ">
                        <span>Filters:</span>
                        <a href=#>&nbsp;</a>
                    </div>
                </div>
                <!-- End .toolbox-left -->


            </nav>

            <div class="row main-content-wrap">
                <div class="col-lg-9 main-content" id="results-container">
                    <div class="row" >

                        @foreach ($products as $key => $product)
                            <?php $product_image = explode(',', $product->image);
                            $product_image = htmlspecialchars($product_image[0]); ?>
                            <div class="col-6 col-sm-4 col-md-3">
                                <div class="product-default">
                                    <figure class="preview_product_1"
                                        style="background-image: url('https://belhassan.brosstock.com/public/images/product/{{ $product_image }}');}">
                                        <a href="{{ url('product/' . $product->id) }}">
                                        </a>
                                    </figure>

                                    <div class="product-details">
                                        <div class="category-wrap">
                                            <div class="category-list">
                                                <a href=""
                                                    class="product-category">{{ $product->category->name }}</a>
                                            </div>
                                        </div>

                                        <h3 class="product-title">
                                            <a href="{{ url('product/' . $product->id) }}">{{ $product->name }}</a>
                                        </h3>

                                        <div class="ratings-container">
                                            <div class="product-ratings">
                                                <span class="ratings"
                                                    style="width:{{ $product->ratings_percentage }}"></span>
                                                <!-- Assuming $product->ratings_percentage contains the percentage of ratings -->
                                                <span class="tooltiptext tooltip-top"></span>
                                            </div>
                                        </div>

                                        <div class="price-box">

                                            <span class="product-price">{{ $product->price }}Dh</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        @endforeach
                        <!-- End .col-sm-4 -->
                    </div>
                    {{ $products->links() }}
                    <!-- End .row -->
                </div>
                <!-- End .col-lg-9 -->

                <div class="sidebar-overlay"></div>
                <aside class="sidebar-shop col-lg-3 order-lg-first mobile-sidebar">
                    <div class="sidebar-wrapper">
                        <div class="widget">
                            <h3 class="widget-title">
                                @isset($category)

                                    @empty(!$category->parent_id)
                                        <a href="{{route('product.searchByCategorie', $category->parent_id)}}"> <span> < </span> {{ $category->name }}</a>
                                        @else
                                        <a data-toggle="collapse" href="#widget-body-2" role="button" aria-expanded="true"
                                        aria-controls="widget-body-2">{{ $category->name }}</a>
                                    @endempty

                                    @else
                                        <a data-toggle="collapse" href="#widget-body-2" role="button" aria-expanded="true"
                                            aria-controls="widget-body-2">Categories</a>
                                @endisset
                            </h3>

                            <div class="collapse show" id="widget-body-2">
                                <div class="widget-body">
                                    <ul class="cat-list cat_list_scroll">
                                        @foreach ($categorys as $category)
                                            <li>
                                                <a href="{{ route('product.searchByCategorie', $category->id) }}"
                                                    aria-expanded="true" aria-controls="widget-category-1">
                                                    {{ $category->name }} <span class="products-count"></span>

                                                </a>

                                            </li>
                                        @endforeach

                                    </ul>
                                </div>
                                <!-- End .widget-body -->
                            </div>
                            <!-- End .collapse -->
                        </div>
                        <!-- End .widget -->

                    </div>
                    <!-- End .sidebar-wrapper -->
                </aside>
                <!-- End .col-lg-3 -->
            </div>
            <!-- End .row -->
        </div>
    </main>
    <script>
        // console.log('here');

        $(document).ready(function(){ // ensure that the page is loaded correctly

            $('#search-input').on('keyup', function(){

                $text = $(this).val();
                $text = $text.trim(); //clear iynput from white spacees ..

                // if ($text == '')
                //     return;

                var category_id = {!! json_encode($category->parent_id) !!};
                $.ajax({
                    url: "{{ route('search') }}",
                    method: 'GET',
                    data: {
                        searchText: $text,
                        idParentCategorie: category_id !== null ? category_id : null

                    },
                    success: function(response) {
                        var resultsContainer = $('#results-container');

                        resultsContainer.empty();

                        resultsContainer.append(resultsContainer.html(response));

                    },
                    error: function(xhr, status, error){
                        console.log('here');
                        console.error('Error', error);
                    }
                });

                $(document).on('click', '.page-link', function (event) {
                        var category_id = {!! json_encode($category->parent_id) !!};
                        event.preventDefault();

                        var page = $(this).attr('href');
                        var searchText = $('#search-input').val();

                        var category_id = {!! json_encode($category->parent_id) !!};
                        $.ajax({
                            url: page,
                            method: 'GET',
                            data:  {
                                searchText: $text,
                                idParentCategorie: category_id !== null ? category_id : null
                            },
                            success: function(response) {
                                var resultsContainer = $('#results-container');

                                resultsContainer.empty();

                                resultsContainer.append(resultsContainer.html(response));

                            },
                            error: function(xhr, status, error){
                                console.log('here');
                                console.error('Error', error);
                            }
                        });

                });



            });



       });



    </script>
    <!-- End .main -->
    @include('layouts/footer')


</html>
