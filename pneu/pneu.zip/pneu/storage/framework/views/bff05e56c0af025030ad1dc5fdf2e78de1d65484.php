
<footer class="footer bg-dark position-relative">
            <div class="footer-middle">
                <div class="container position-static">
                    <div class="row">
                        <div class="col-lg-2 col-sm-6 pb-2 pb-sm-0 d-flex align-items-center">
                            <div class="widget m-b-3">
                                <img src="assets/images/demoes/demo42/footer-logo.png" alt="Logo" width="202"
                                    height="54" class="logo-footer">
                            </div><!-- End .widget -->
                        </div><!-- End .col-lg-3 -->

                        <div class="col-lg-3 col-sm-6 pb-4 pb-sm-0">
                            <div class="widget mb-2">
                                <h4 class="widget-title mb-1 pb-1">Get In Touch</h4>
                                <ul class="contact-info">
                                    <li>
                                        <span class="contact-info-label">Address:</span>Pneumatiques belhassan, 51100, Ain Taoujdate 51100
                                    </li>
                                    <li>
                                        <span class="contact-info-label">Phone:</span><a href="tel:">Toll Free (123)
                                            456-7890</a>
                                    </li>
                              
                                    <li>
                                        <span class="contact-info-label">Working Days/Hours:</span>
                                        Mon - Sun / 9:00 AM - 8:00 PM
                                    </li>
                                </ul>
                                <div class="social-icons">
                                    <a href="https://www.facebook.com/people/Belhassan-Spb/pfbid02tjWbENJZXiu7Xi9gHSwv47bSwnkGADwvrv2inWN2TMSAiVaHQsgfPCotEVcqYbRFl/?mibextid=LQQJ4d" class="social-icon social-facebook icon-facebook" target="_blank"
                                        title="Facebook"></a>
                                        <a href="https://instagram.com/belhassan_spb?igshid=Y2I2MzMwZWM3ZA==" class="social-icon social-instagram icon-instagram" target="_blank" title="instagram">
                                        </a>
                                    
                                </div><!-- End .social-icons -->
                            </div><!-- End .widget -->
                        </div><!-- End .col-lg-3 -->

                        <div class="col-lg-3 col-sm-6 pb-2 pb-sm-0">
                            <div class="widget">
                                <h4 class="widget-title pb-1">Rapide lien</h4>

                                <ul class="links">
                                  
                                    <li><a href="">About Us</a></li>
                                </ul>
                            </div><!-- End .widget -->
                        </div><!-- End .col-lg-3 -->

                      
                    </div><!-- End .row -->
                </div><!-- End .container -->
            </div><!-- End .footer-middle -->

            <div class="container">
                <div class="footer-bottom d-sm-flex align-items-center bg-dark">
                    <div class="footer-left">
                        <span class="footer-copyright">Pneumatique Belhassan. © 2023. All Rights Reserved</span>
                    </div>

                 
                </div>
            </div><!-- End .footer-bottom -->
        </footer>
        </div>

<div class="mobile-menu-overlay"></div><!-- End .mobil-menu-overlay -->

<div class="mobile-menu-container">
    <div class="mobile-menu-wrapper">
        <span class="mobile-menu-close"><i class="fa fa-times"></i></span>
        <nav class="mobile-nav">
            <ul class="mobile-menu">
                <li><a href="">Home</a></li>
              
            
             
                <li>
                    <a href="#">Elements</a>
                    <ul class="custom-scrollbar">
                        <li><a href="">Accordion</a></li>
                    </ul>
                </li>
            </ul>

       

        </nav>

        <div class="social-icons">
            <a href="https://www.facebook.com/people/Belhassan-Spb/pfbid02tjWbENJZXiu7Xi9gHSwv47bSwnkGADwvrv2inWN2TMSAiVaHQsgfPCotEVcqYbRFl/?mibextid=LQQJ4d" class="social-icon social-facebook icon-facebook" target="_blank" title="facebook">
            </a>
           
            <a href="https://instagram.com/belhassan_spb?igshid=Y2I2MzMwZWM3ZA==" class="social-icon social-instagram icon-instagram" target="_blank" title="instagram">
            </a>
        </div>
    </div><!-- End .mobile-menu-wrapper -->
</div><!-- End .mobile-menu-container -->




<a id="scroll-top" href="#top" title="Top" role="button"><i class="icon-angle-up"></i></a>

<!-- Plugins JS File -->
<script data-cfasync="false" src="../../cdn-cgi/scripts/5c5dd728/cloudflare-static/email-decode.min.js"></script>
<script src="<?php echo e(asset('assets/js/jquery.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/bootstrap.bundle.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/optional/isotope.pkgd.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/plugins.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.appear.min.js')); ?>"></script>
<script src="<?php echo e(asset('assets/js/jquery.plugin.min.js')); ?>"></script>

<!-- Main JS File -->
<script src="<?php echo e(asset('assets/js/main.min.js')); ?>"></script>
<script>(function(){var js = "window['__CF$cv$params']={r:'7e41bb8e38741854',m:'ZtJgruW5gPYGuFgw7YgisfiFJGW86guwxfpe7uxGT.Y-1688917931-0-AeqjtFZftk3M33h30vfxRAvas8oq94x5EWw+w54Y7iU6'};_cpo=document.createElement('script');_cpo.nonce='',_cpo.src='../../cdn-cgi/challenge-platform/h/g/scripts/jsd/19b997cb/invisible.js',document.getElementsByTagName('head')[0].appendChild(_cpo);";var _0xh = document.createElement('iframe');_0xh.height = 1;_0xh.width = 1;_0xh.style.position = 'absolute';_0xh.style.top = 0;_0xh.style.left = 0;_0xh.style.border = 'none';_0xh.style.visibility = 'hidden';document.body.appendChild(_0xh);function handler() {var _0xi = _0xh.contentDocument || _0xh.contentWindow.document;if (_0xi) {var _0xj = _0xi.createElement('script');_0xj.nonce = '';_0xj.innerHTML = js;_0xi.getElementsByTagName('head')[0].appendChild(_0xj);}}if (document.readyState !== 'loading') {handler();} else if (window.addEventListener) {document.addEventListener('DOMContentLoaded', handler);} else {var prev = document.onreadystatechange || function () {};document.onreadystatechange = function (e) {prev(e);if (document.readyState !== 'loading') {document.onreadystatechange = prev;handler();}};}})();</script></body>

<?php /**PATH C:\Users\yousr\OneDrive\Bureau\pneu\resources\views/layouts/footer.blade.php ENDPATH**/ ?>