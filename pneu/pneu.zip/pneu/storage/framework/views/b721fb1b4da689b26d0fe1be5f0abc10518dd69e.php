<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from portotheme.com/html/porto_ecommerce/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 09 Jul 2023 16:11:56 GMT -->
<head>
	<meta charset="UTF-8">
	<meta http-equiv="X-UA-Compatible" content="IE=edge">
	<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

	<title>belhassan- Bootstrap eCommerce Template</title>

	<meta name="keywords" content="HTML5 Template" />
	<meta name="description" content="belhassan- Bootstrap eCommerce Template">
	<meta name="author" content="SW-THEMES">


	<!DOCTYPE html>
	<html lang="en">
	
	<head>
		<meta charset="UTF-8">
		<meta http-equiv="X-UA-Compatible" content="IE=edge">
		<meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
	
		<title>Pneumatiques belhassan</title>
	
		<meta name="keywords" content="Pneumatiques belhassan,Pneumatiques " />
		<meta name="description" content="Pneumatiques belhassan">
		<?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

		<main class="main">
			<div class="contact1" style="background: #ececec">

				<nav aria-label="breadcrumb" class="breadcrumb-nav">
					<div class="container">
						<ol class="breadcrumb">
							<li class="breadcrumb-item">
								<a href="demo4.html"><i class="icon-home"></i></a>
							</li>
							<li class="breadcrumb-item active" aria-current="page">
								Contact Us
							</li>
						</ol>
					</div>
				</nav>


				<div class="container contact-us-container">
					<div class="contact-info">
						<div class="row">
							<div class="col-12">
								<h2 class="ls-n-25 m-b-1">
									Contact Info
								</h2>

								
							</div>

							<div class="col-sm-6 col-lg-6">
								<div class="feature-box text-center">
									<i class="sicon-location-pin"></i>
									<div class="feature-box-content">
										<h3>Address</h3>
										<h5>Pneumatiques belhassan, 51100, Ain Taoujdate 51100</h5>
									</div>
								</div>
							</div>
							<div class="col-sm-6 col-lg-6">
								<div class="feature-box text-center">
									<i class="fa fa-mobile-alt"></i>
									<div class="feature-box-content">
										<h3>Phone Number</h3>
										<h5>(+212) 5 32 08 16 05</h5>
									</div>
								</div>
							</div>
							
						</div>
					</div>

					
				</div>
				<iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3309.944470517268!2d-5.217573!3d33.94255630000001!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0xda02542b0885c87%3A0xeee71410cc6cfc3b!2sPneumatiques%20belhassan!5e0!3m2!1sfr!2sfr!4v1688922551130!5m2!1sfr!2sfr" width="100%" height="450" style="border:0;" allowfullscreen="" loading="lazy" referrerpolicy="no-referrer-when-downgrade"></iframe>
			</div>

		</main>

	<!-- End .main -->
    <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH C:\Users\Brosmedia\Downloads\pneu\pneu\resources\views/contact.blade.php ENDPATH**/ ?>