<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from portotheme.com/html/porto_ecommerce/contact.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 09 Jul 2023 16:11:56 GMT -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>belhassan- Bootstrap eCommerce Template</title>

    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="belhassan- Bootstrap eCommerce Template">
    <meta name="author" content="SW-THEMES">


    <!DOCTYPE html>
    <html lang="en">

    <head>
        <meta charset="UTF-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

        <title>Pneumatiques belhassan</title>

        <meta name="keywords" content="Pneumatiques belhassan,Pneumatiques " />
        <meta name="description" content="Pneumatiques belhassan">
        <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        <main class="main">

            <div class="row">
                <div class="col-md-6" style="background-color: black;">
                    <div class="b-5" style="    color: #fff;
                    padding: 40px;">
                        <h1 class="m-3 " style="color: #fff">Bienvenue chez Pneumatique <br> BELHASSAN !</h1>

                        <p class="m-4" style="font-size: 19px;
                        font-family: inherit;"> Votre destination incontournable pour tous vos besoins en matière de pneus,
                            jantes et équipements dans le domaine de l'automobile. Nous sommes fiers de vous offrir une
                            gamme complète de produits et de services de haute qualité pour répondre à toutes vos
                            exigences.</p>

                        <p class="m-4" style="font-size: 19px;
                        font-family: inherit;">Notre société se spécialise dans la vente de pneus et de jantes de premier choix, adaptés à
                            tous types de véhicules, des voitures particulières aux véhicules utilitaires et poids
                            lourds. Que vous cherchiez des pneus performants pour une conduite en douceur sur l'asphalte
                            ou des pneus tout-terrain robustes pour des aventures hors route, notre sélection saura
                            satisfaire vos besoins spécifiques.

                            En plus de notre vaste catalogue de produits, nous proposons également des équipements de
                            pointe pour les nouvelles entreprises dans le domaine automobile. Que vous débutiez dans
                            l'industrie ou que vous cherchiez à améliorer vos services existants, notre équipe d'experts
                            est là pour vous conseill
                        </p>
                        <div class="row">
                            <button class="btn m-5">Products</button>
                        </div>
                    </div>
                </div>
                <div class="col-md-6"
                    style="background: url(https://media.istockphoto.com/id/908021140/photo/silhouette-of-black-sports-car-on-black.webp?b=1&s=170667a&w=0&k=20&c=NrrU9Tjw1FtUnrEU7lHvfgeYmWGxEQzsHljAR8StPh0=);
                background-size: 100%;
                background-position: center;
                height: 700px;">

                </div>
            </div>

        </main>

        <!-- End .main -->
        <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    </html>
<?php /**PATH C:\Users\Brosmedia\Downloads\pneu\pneu\resources\views/about.blade.php ENDPATH**/ ?>