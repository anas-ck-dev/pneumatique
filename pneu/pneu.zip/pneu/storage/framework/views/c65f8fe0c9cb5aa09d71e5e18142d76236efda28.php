<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Pneumatiques belhassan</title>

    <meta name="keywords" content="Pneumatiques belhassan,Pneumatiques " />
    <meta name="description" content="Pneumatiques belhassan">
    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

    <main class="main">
        <div class="intro-slider slide-animate owl-carousel owl-theme show-nav-hover nav-inside nav-big"
            data-owl-options="{
                'loop': false,
                'dots': false,
                'nav': true
			}">
            <div class="banner intro-slide1"
                style="background: url(//assets/images/demoes/demo42/slider/slide1.jpg) rgb(255, 255, 255);
                min-height: 530px; background-position: right center; background-repeat: no-repeat;">
                <div class="container">
                    <div class="wrapper">
                        <svg class="custom-svg-1" version="1.1" xmlns="http://www.w3.org/2000/svg"
                            xmlns:xlink="http://www.w3.org/1999/xlink" x="0px" y="0px"
                            viewBox="0 0 649 578">
                            <path fill="#FFF"
                                d="M-225.5,154.7l358.45,456.96c7.71,9.83,21.92,11.54,31.75,3.84l456.96-358.45c9.83-7.71,11.54-21.92,3.84-31.75
                                    L267.05-231.66c-7.71-9.83-21.92-11.54-31.75-3.84l-456.96,358.45C-231.49,130.66-233.2,144.87-225.5,154.7z">
                            </path>
                            <path class="appear-animate appear-animate-svg" data-animation-name="customLineAnim"
                                data-animation-duration="5000" fill="none" stroke="#222529" stroke-width="1.5"
                                stroke-miterlimit="10" d="M416-21l202.27,292.91c5.42,7.85,3.63,18.59-4.05,24.25L198,603"
                                style="animation-delay: 300ms; animation-duration: 5s;"></path>
                        </svg>
                    </div>
                    <div class="row h-100">
                        <div class="col-md-5 banner-media appear-animate d-none d-md-block"
                            data-animation-name="fadeInRightShorter">
                            <img src="/assets/images/demoes/demo42/banner1.jpg" width="426" height="426"
                                alt="banner" />

                        </div>
                        <div class="col-md-7">
                            <div class="banner-content banner-layer-middle">
                                <div class=" appear-animate" data-animation-name="fadeInLeftShorter"
                                    data-animation-delay="500">
                                    <h2 class="banner-title pb-1">Notre plateforme de vente en ligne vous propose une
                                        multitude de marques, ce qui nous permet d'avoir des prix adaptés à tous les
                                        budgets.</h2>
                                    <div class="banner-action">
                                        <a href="#produits" class="btn btn-primary btn-rounded btn-icon-right"
                                            role="button">Achetez
                                            <i class="fas fa-arrow-right"></i>
                                        </a>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            
        </div>



        <section class="search-section" style="background-color: #f4f4f4;">
            <div class="container">
                <div class="row justify-content-center">

                    <div class="col-sm-12 col-md-4">
                        <h2 class="search-title p-2 mr-4"><i class="icon-business-book"></i>TROUVEZ VOTRE PRODUIT:</h2>
                    </div>

                    <div class="col-sm-12 col-md-4">
                        <div class="select-custom">
                            <select class="form-control mb-0" name="search_categorie" id="select1"
                                style="font-size: 15px;">
                                <option>
                                    <?php if(isset($category)): ?>
                                        <?php echo e($category->name); ?>

                                    <?php else: ?>
                                        Par Categories
                                    <?php endif; ?>
                                </option>
                                <?php if(empty($category->id)): ?>
                                    <?php $category_id = 0; ?>
                                    <?php else: ?>
                                    <?php $category_id = $category->id; ?>
                                <?php endif; ?>

                                <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category1): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($category1->id); ?>"
                                        <?php if($category_id == $category1->id): ?> selected <?php endif; ?>>
                                        <?php echo e($category1->name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                </div>

            </div>
        </section>
        <script>
            $('#select1').trigger('change');

            $("#select1")
                .on("change", function() {
                    var str = "";
                    $("select option:selected").each(function() {
                        str += $(this).val() + " ";
                        window.location = '/product/search/' + str;
                    });

                });
        </script>
        <div class="container" id="produits">
            <h2 class="title title-underline pb-1 appear-animate mt-3" data-animation-name="fadeInLeftShorter">Produits</h2>

            <nav class="toolbox sticky-header horizontal-filter mb-1" data-sticky-options="{'mobile': true}">
                <div class="toolbox-left">


                    <div class="toolbox-item filter-toggle  d-lg-flex ">
                        <span>Filters:</span>
                        <a href=#>&nbsp;</a>
                    </div>
                </div>
                <!-- End .toolbox-left -->


            </nav>

            <div class="row main-content-wrap">
                <div class="col-lg-9 main-content">
                    <div class="row">

                        <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $product_image = explode(',', $product->image);
                            $product_image = htmlspecialchars($product_image[0]); ?>
                            <div class="col-6 col-sm-4 col-md-3">
                                <div class="product-default">
                                    <figure class="preview_product_1"
                                        style="background-image: url('https://belhassan.brosstock.com/public/images/product/<?php echo e($product_image); ?>');}">
                                        <a href="<?php echo e(url('product/' . $product->id)); ?>">
                                        </a>
                                    </figure>

                                    <div class="product-details">
                                        <div class="category-wrap">
                                            <div class="category-list">
                                                <a href=""
                                                    class="product-category"><?php echo e($product->category->name); ?></a>
                                            </div>
                                        </div>

                                        <h3 class="product-title">
                                            <a href="<?php echo e(url('product/' . $product->id)); ?>"><?php echo e($product->name); ?></a>
                                        </h3>

                                        <div class="ratings-container">
                                            <div class="product-ratings">
                                                <span class="ratings"
                                                    style="width:<?php echo e($product->ratings_percentage); ?>"></span>
                                                <!-- Assuming $product->ratings_percentage contains the percentage of ratings -->
                                                <span class="tooltiptext tooltip-top"></span>
                                            </div>
                                        </div>

                                        <div class="price-box">

                                            <span class="product-price"><?php echo e($product->price); ?>Dh</span>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                        <!-- End .col-sm-4 -->
                    </div>
                    <?php echo e($products->links()); ?>

                    <!-- End .row -->


                </div>
                <!-- End .col-lg-9 -->

                <div class="sidebar-overlay"></div>
                <aside class="sidebar-shop col-lg-3 order-lg-first mobile-sidebar">
                    <div class="sidebar-wrapper">
                        <div class="widget">
                            <h3 class="widget-title">
                                <?php if(isset($category)): ?>
                                    
                                    <?php if(empty(!$category->parent_id)): ?>
                                        <a href="<?php echo e(route('product.searchByCategorie', $category->parent_id)); ?>"> <span> < </span> <?php echo e($category->name); ?></a>
                                        <?php else: ?>
                                        <a data-toggle="collapse" href="#widget-body-2" role="button" aria-expanded="true"
                                        aria-controls="widget-body-2"><?php echo e($category->name); ?></a>
                                    <?php endif; ?> 

                                    <?php else: ?>
                                        <a data-toggle="collapse" href="#widget-body-2" role="button" aria-expanded="true"
                                            aria-controls="widget-body-2">Categories</a>
                                <?php endif; ?>
                            </h3>

                            <div class="collapse show" id="widget-body-2">
                                <div class="widget-body">
                                    <ul class="cat-list cat_list_scroll">
                                        <?php $__currentLoopData = $categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <li>
                                                <a href="<?php echo e(route('product.searchByCategorie', $category->id)); ?>"
                                                    aria-expanded="true" aria-controls="widget-category-1">
                                                    <?php echo e($category->name); ?> <span class="products-count"></span>

                                                </a>

                                            </li>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                    </ul>
                                </div>
                                <!-- End .widget-body -->
                            </div>
                            <!-- End .collapse -->
                        </div>
                        <!-- End .widget -->




                    </div>
                    <!-- End .sidebar-wrapper -->
                </aside>
                <!-- End .col-lg-3 -->
            </div>
            <!-- End .row -->
        </div>
    </main>
    <!-- End .main -->
    <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH C:\Users\Brosmedia\Desktop\projet-laravel\pneu\pneu\resources\views/index.blade.php ENDPATH**/ ?>