<div class="row" >
<?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
<?php $product_image = explode(',', $product->image);
$product_image = htmlspecialchars($product_image[0]); ?>

<div class="col-6 col-sm-4 col-md-3">
    <div class="product-default">
        <figure class="preview_product_1"
            style="background-image: url('https://belhassan.brosstock.com/public/images/product/<?php echo e($product_image); ?>');}">
            <a href="<?php echo e(url('product/' . $product->id)); ?>">
            </a>
        </figure>

        <div class="product-details">
            <div class="category-wrap">
                <div class="category-list">
                    <a href=""
                        class="product-category"><?php echo e($product->category->name); ?></a>
                </div>
            </div>

            <h3 class="product-title">
                <a href="<?php echo e(url('product/' . $product->id)); ?>"><?php echo e($product->name); ?></a>
            </h3>

            <div class="ratings-container">
                <div class="product-ratings">
                    <span class="ratings"
                        style="width:<?php echo e($product->ratings_percentage); ?>"></span>
                    <!-- Assuming $product->ratings_percentage contains the percentage of ratings -->
                    <span class="tooltiptext tooltip-top"></span>
                </div>
            </div>

            <div class="price-box">

                <span class="product-price"><?php echo e($product->price); ?>Dh</span>
            </div>
        </div>
    </div>
</div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php echo e($products->links()); ?>

<?php /**PATH C:\Users\Brosmedia\Desktop\projet-laravel\pneu\resources\views/search.blade.php ENDPATH**/ ?>