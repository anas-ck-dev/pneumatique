<!DOCTYPE html>
<html lang="en">


<!-- Mirrored from portotheme.com/html/porto_ecommerce/demo42-shop.html by HTTrack Website Copier/3.x [XR&CO'2014], Sun, 09 Jul 2023 16:22:41 GMT -->

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title>Categorie <?php echo e($category->name); ?></title>

    <meta name="keywords" content="HTML5 Template" />
    <meta name="description" content="belhassan- Bootstrap eCommerce Template">
    <meta name="author" content="SW-THEMES">



    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="main">
        <div class="container">
            <nav aria-label="breadcrumb" class="breadcrumb-nav">
                <ol class="breadcrumb">
                    <li class="breadcrumb-item"><a href="/"><i class="icon-home"></i></a></li>
                    <li class="breadcrumb-item active" aria-current="page">SHOP</li>
                </ol>
            </nav>

            <div class="row">
                <div class="col-lg-9 main-content">


                    <div class="row">
                        <?php if($products->count()): ?>
                            <?php $__currentLoopData = $products; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <div class="col-6 col-sm-4">
                                    

                                    <div class="product-default">
                                        <figure class="preview_product_1"
                                            style="background-image: url('https://belhassan.brosstock.com/public/images/product/<?php echo e($product->image); ?>');}">
                                            <a href="<?php echo e(url('product/' . $product->id)); ?>">
                                            </a>
                                        </figure>

                                        <div class="product-details">
                                            

                                            <h3 class="product-title">
                                                <a href="<?php echo e(url('product/' . $product->id)); ?>"><?php echo e($product->name); ?></a>
                                            </h3>

                                            <div class="ratings-container">
                                                <div class="product-ratings">
                                                    <span class="ratings"
                                                        style="width:<?php echo e($product->ratings_percentage); ?>"></span>
                                                    <!-- Assuming $product->ratings_percentage contains the percentage of ratings -->
                                                    <span class="tooltiptext tooltip-top"></span>
                                                </div>
                                            </div>

                                            <div class="price-box">

                                                <span class="product-price"><?php echo e($product->price); ?>Dh</span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <!-- End .col-sm-4 -->
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <?php else: ?>
                            <div class="alert alert-info w-100 pl-5">dosn't have a products</div>
                        <?php endif; ?>


                    </div>
                    <?php echo e($products->links()); ?>

                    <!-- End .row -->


                </div>
                <!-- End .col-lg-9 -->

                <div class="sidebar-overlay"></div>
                <aside class="sidebar-shop col-lg-3 order-lg-first mobile-sidebar">
                    <div class="sidebar-wrapper">
                        <div class="widget">
                            


                            <h3 class="widget-title">
                                <?php if(empty(!$category->parent_id)): ?>
                                    <a href="<?php echo e(route('category.listing', $category->parent_id)); ?>"> <span>
                                            < </span> <?php echo e($category->name); ?></a>
                                <?php else: ?>
                                    <a href="#"><?php echo e($category->name); ?></a>
                                <?php endif; ?>
                            </h3>

                            <div class="collapse show" id="widget-body-2">
                                <div class="widget-body">
                                    <ul class="cat-list cat_list_scroll">

                                        <?php $__currentLoopData = $fils_categorys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $fil_category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            

                                            <li>

                                                <a href="<?php echo e(route('category.listing', $fil_category->id)); ?>">
                                                    <?php echo e($fil_category->name); ?>


                                                    
                                                    <i class="fa-solid fa-right-long"></i>
                                                    
                                                </a>

                                            </li>
                                            
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </div>
                                <!-- End .widget-body -->
                            </div>
                            <!-- End .collapse -->
                            
                        </div>
                        <!-- End .widget -->
                    </div>
                    <!-- End .sidebar-wrapper -->
                </aside>
                <!-- End .col-lg-3 -->
            </div>
            <!-- End .row -->
        </div>
        <!-- End .container -->

        <div class="mb-4"></div>
        <!-- margin -->
    </main>
    <!-- End .main -->

    <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH C:\Users\Brosmedia\Downloads\pneu\pneu\resources\views/listing_product.blade.php ENDPATH**/ ?>