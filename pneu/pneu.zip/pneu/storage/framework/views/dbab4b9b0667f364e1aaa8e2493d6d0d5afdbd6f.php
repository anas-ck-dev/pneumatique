<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <title><?php echo e($product->name); ?></title>


    <meta property="og:url" content="<?php echo e(url()->full()); ?>" />
    <meta property="og:type" content="website" />
    <meta property="og:title" content="<?php echo e(Str::limit($product->name, 60)); ?>" />
    <meta property="og:description" content="<?php echo e(Str::limit($product->product_details, 80)); ?>" />
    <meta property="og:image" content="https://belhassan.brosstock.com/public/images/product/<?php echo e($product->image); ?>" />

    <meta name="keywords" content="Pneumatiques belhassan,Pneumatiques " />
    <meta name="description" content="<?php echo e($product->product_details); ?>">
    <?php echo $__env->make('layouts/header', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    <main class="main">
        <div class="container">


            <div class="product-single-container product-single-default">
                <div class="cart-message d-none">
                    <strong class="single-cart-notice"><?php echo e($product->name); ?></strong>
                    <span>has been added to your cart.</span>
                </div>

                <div class="row">
                    <div class="col-lg-5 col-md-6 product-single-gallery">
                        <div class="product-slider-container">

                            <div class="product-single-carousel owl-carousel owl-theme show-nav-hover">
                                <div class="product-item">
                                    <img class="product-single-image"
                                        src="https://belhassan.brosstock.com/public/images/product/<?php echo e($product->image); ?>"
                                        data-zoom-image="https://belhassan.brosstock.com/public/images/product/<?php echo e($product->image); ?>"
                                        width="468" height="468" alt="product" />
                                </div>
                            </div>
                            <!-- End .product-single-carousel -->
                            <span class="prod-full-screen">
                                <i class="icon-plus"></i>
                            </span>
                        </div>

                        
                    </div><!-- End .product-single-gallery -->

                    <div class="col-lg-7 col-md-6 product-single-details" style="padding: 50px">
                        <?php if(session()->has('success')): ?>
                            <div class="alert alert-success">
                                <?php echo e(session()->get('success')); ?>

                            </div>
                        <?php endif; ?>
                        <?php if(session()->has('failed')): ?>
                            <div class="alert alert-danger">
                                <?php echo e(session()->get('failed')); ?>

                            </div>
                        <?php endif; ?>
                        <h1 class="product-title" title="<?php echo e($product->name); ?>">
                            <?php echo e(Str::limit($product->name, 60)); ?></h1>

                        <div class="product-nav d-none">
                            <div class="product-prev">
                                <a href="#">
                                    <span class="product-link"></span>

                                    <span class="product-popup">
                                        <span class="box-content">
                                            <img alt="product" width="150" height="150"
                                                src="/assets/images/products/product-3.jpg" style="padding-top: 0px;">

                                            <span>Circled Ultimate 3D Speaker</span>
                                        </span>
                                    </span>
                                </a>
                            </div>

                            <div class="product-next">
                                <a href="#">
                                    <span class="product-link"></span>

                                    <span class="product-popup">
                                        <span class="box-content">
                                            <img alt="product" width="150" height="150"
                                                src="/assets/images/products/product-4.jpg" style="padding-top: 0px;">

                                            <span>Blue Backpack for the Young</span>
                                        </span>
                                    </span>
                                </a>
                            </div>
                        </div>

                        <hr class="short-divider">

                        <div class="price-box mt-5">
                            <span class="product-price"> <?php echo e($product->price); ?>Dh</span>
                        </div><!-- End .price-box -->

                        <div class="product-desc">
                            <p><?php echo e($product->product_details); ?></p>
                        </div><!-- End .product-desc -->

                        <ul class="single-info-list">
                            <!---->
                            

                            <li>
                                CATEGORY:
                                <strong>
                                    <a href="#" class="product-category"><?php echo e($product->category->name); ?>

                                    </a>


                                    <?php
                                    $disabled="";
                                    if ($product->qty <= 0) {
                                        $disabled="disabled";
                                    ?>
<br>
                                        <span class="alert-danger" > Ripture de stock</span>

                                        <?php

                                    }


                                    ?>
                                </strong>
                            </li>


                            <form action="<?php echo e(route('command.store')); ?>" method="post">
                                <?php echo csrf_field(); ?>

                                <input type="number"  class="d-none" name="product_id" value="<?php echo e($product->id); ?>">
                                <div class="product-container">
                                    <label for="quantity">Quantité</label>

                                    <div class="product-quantity">

                                        <input type="number" name="quantity"  value="1" min="1" <?php echo $disabled ?>
                                            max="<?php echo e($product->qty); ?>" />
                                        <?php $__errorArgs = ['quantity'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                            <div class="alert alert-danger"><?php echo e($message); ?></div>
                                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                    </div>
                                </div>

                                <div class="modal-body">
                                    <div class="row">
                                        <div class="col-md-6 col-sm-12">
                                            <div class=" ">
                                                <label for="full_name">Nom Complet</label>
                                                <input type="text" id="full_name" name="full_name"
                                                    class="form-control com" required
                                                    placeholder="Entrez votre nom complet"  <?php echo $disabled ?>>
                                                <?php $__errorArgs = ['full_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class=" ">
                                                <label for="address">Address</label>
                                                <input type="text" id="address" name="address"
                                                    class="form-control com" required placeholder="Entrez votre Address" <?php echo $disabled ?>>
                                                <?php $__errorArgs = ['address'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>
                                        <div class="col-md-6 col-sm-12">
                                            <div class=" ">
                                                <label for="tel">Téléphone</label>
                                                <input type="tel" id="tel" name="tel"
                                                    class="form-control com" required placeholder="Entrez votre tel" <?php echo $disabled ?>>
                                                <?php $__errorArgs = ['tel'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                                    <div class="alert alert-danger"><?php echo e($message); ?></div>
                                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                                            </div>
                                        </div>

                                    </div>
                                </div>
                                
                                    <button type="submit" class="btn btn-primary com" <?php echo $disabled ?>>shop now</button>
                               
                            </form>
                        </ul>

                        <div class="product-action d-none">

                            <div class="product-single-qty">
                                <input class="horizontal-quantity form-control" type="text">
                            </div><!-- End .product-single-qty -->

                            <a href="javascript:;" class="btn btn-dark add-cart mr-2" title="Add to Cart">Add to
                                Cart</a>

                            <a href="cart.html" class="btn btn-gray view-cart d-none">View cart</a>
                        </div><!-- End .product-action -->


                        <div class="product-single-share mb-2">
                            <label class="sr-only">Share:</label>

                            
                            <script>
                                function shareOnWhatsApp() {
                                    const productLink = 'http://127.0.0.1:8000/product/11';

                                    // Generate the WhatsApp sharing URL with the product link and a default message (optional).
                                    const sharingUrl =
                                        `https://api.whatsapp.com/send?text=${encodeURIComponent(productLink)}`;

                                    // Open a new window to share the product on WhatsApp.
                                    window.open(sharingUrl, '_blank', 'width=600,height=400');
                                }
                            </script>
                            

                            <a href="wishlist.html" class="btn-icon-wish add-wishlist d-none"
                                title="Add to Wishlist"><i class="icon-wishlist-2"></i><span>Add to
                                    Wishlist</span></a>
                        </div><!-- End .product single-share -->
                    </div><!-- End .product-single-details -->
                </div><!-- End .row -->
            </div><!-- End .product-single-container -->

            <div class="product-single-tabs">
                <ul class="nav nav-tabs" role="tablist">
                    <li class="nav-item">
                        <a class="nav-link active" id="product-tab-desc" data-toggle="tab"
                            href="#product-desc-content" role="tab" aria-controls="product-desc-content"
                            aria-selected="true">Description</a>
                    </li>

                    <li class="nav-item d-none">
                        <a class="nav-link" id="product-tab-tags" data-toggle="tab" href="#product-tags-content"
                            role="tab" aria-controls="product-tags-content" aria-selected="false">Additional
                            Information</a>
                    </li>

                    <li class="nav-item d-none">
                        <a class="nav-link" id="product-tab-reviews" data-toggle="tab"
                            href="#product-reviews-content" role="tab" aria-controls="product-reviews-content"
                            aria-selected="false">Reviews (1)</a>
                    </li>
                </ul>

                <div class="tab-content">
                    <div class="tab-pane fade show active" id="product-desc-content" role="tabpanel"
                        aria-labelledby="product-tab-desc">
                        <div class="product-desc-content">
                            <?php echo e($product->product_details); ?>

                        </div><!-- End .product-desc-content -->
                    </div><!-- End .tab-pane -->

                    <div class="tab-pane fade d-none" id="product-tags-content" role="tabpanel"
                        aria-labelledby="product-tab-tags">
                        <table class="table table-striped mt-2">
                            <tbody>
                                <tr>
                                    <th>Weight</th>
                                    <td>23 kg</td>
                                </tr>

                                <tr>
                                    <th>Dimensions</th>
                                    <td>12 × 24 × 35 cm</td>
                                </tr>

                                <tr>
                                    <th>Color</th>
                                    <td>Black, Green, Indigo</td>
                                </tr>

                                <tr>
                                    <th>Size</th>
                                    <td>Large, Medium, Small</td>
                                </tr>
                            </tbody>
                        </table>
                    </div><!-- End .tab-pane -->

                    <div class="tab-pane fade d-none" id="product-reviews-content" role="tabpanel"
                        aria-labelledby="product-tab-reviews">
                        <div class="product-reviews-content">
                            <h3 class="reviews-title">1 review for Men Black Sports Shoes</h3>

                            <div class="comment-list">
                                <div class="comments">
                                    <figure class="img-thumbnail">
                                        <img src="/assets/images/blog/author.jpg" alt="author" width="80"
                                            height="80">
                                    </figure>

                                    <div class="comment-block">
                                        <div class="comment-header">
                                            <div class="comment-arrow"></div>

                                            <div class="ratings-container float-sm-right">
                                                <div class="product-ratings">
                                                    <span class="ratings" style="width:60%"></span>
                                                    <!-- End .ratings -->
                                                    <span class="tooltiptext tooltip-top"></span>
                                                </div><!-- End .product-ratings -->
                                            </div>

                                            <span class="comment-by">
                                                <strong>Joe Doe</strong> – April 12, 2018
                                            </span>
                                        </div>

                                        <div class="comment-content">
                                            <p>Excellent.</p>
                                        </div>
                                    </div>
                                </div>
                            </div>

                            <div class="divider"></div>

                            <div class="add-product-review">
                                <h3 class="review-title">Add a review</h3>

                                <form action="#" class="comment-form m-0">
                                    <div class="rating-form">
                                        <label for="rating">Your rating <span class="required">*</span></label>
                                        <span class="rating-stars">
                                            <a class="star-1" href="#">1</a>
                                            <a class="star-2" href="#">2</a>
                                            <a class="star-3" href="#">3</a>
                                            <a class="star-4" href="#">4</a>
                                            <a class="star-5" href="#">5</a>
                                        </span>

                                        <select name="rating" id="rating" required="" style="display: none;">
                                            <option value="">Rate…</option>
                                            <option value="5">Perfect</option>
                                            <option value="4">Good</option>
                                            <option value="3">Average</option>
                                            <option value="2">Not that bad</option>
                                            <option value="1">Very poor</option>
                                        </select>
                                    </div>

                                    <div class="form-group">
                                        <label>Your review <span class="required">*</span></label>
                                        <textarea cols="5" rows="6" class="form-control form-control-sm"></textarea>
                                    </div><!-- End .form-group -->


                                    <div class="row">
                                        <div class="col-md-6 col-xl-12">
                                            <div class="form-group">
                                                <label>Name <span class="required">*</span></label>
                                                <input type="text" class="form-control form-control-sm" required>
                                            </div><!-- End .form-group -->
                                        </div>

                                        <div class="col-md-6 col-xl-12">
                                            <div class="form-group">
                                                <label>Email <span class="required">*</span></label>
                                                <input type="text" class="form-control form-control-sm" required>
                                            </div><!-- End .form-group -->
                                        </div>

                                        <div class="col-md-12">
                                            <div class="custom-control custom-checkbox">
                                                <input type="checkbox" class="custom-control-input" id="save-name" />
                                                <label class="custom-control-label mb-0" for="save-name">Save my
                                                    name, email, and website in this browser for the next time I
                                                    comment.</label>
                                            </div>
                                        </div>
                                    </div>

                                    <input type="submit" class="btn btn-primary" value="Submit">
                                </form>
                            </div><!-- End .add-product-review -->
                        </div><!-- End .product-reviews-content -->
                    </div><!-- End .tab-pane -->
                </div><!-- End .tab-content -->
            </div><!-- End .product-single-tabs -->

            
        </div><!-- End .container -->
    </main><!-- End .main -->

    <script>
        $(function() {

            $('<span class="add" uk-icon="plus">+</span>').insertAfter(
                '.product-container .product-quantity input');
            $('<span class="sub" uk-icon="minus">-</span>').insertBefore(
                '.product-container .product-quantity input');


            $('.add').click(function() {
                var selectedInput = $(this).prev('input');
                if (selectedInput.val() < 10) {
                    selectedInput[0].stepUp(1);
                }
            });

            $('.sub').click(function() {
                var selectedInput = $(this).next('input');
                if (selectedInput.val() > 0) {
                    selectedInput[0].stepDown(1);
                }
            });


        });
    </script>
    <?php echo $__env->make('layouts/footer', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

</html>
<?php /**PATH C:\Users\yousr\OneDrive\Bureau\pneu\pneu\resources\views/product.blade.php ENDPATH**/ ?>